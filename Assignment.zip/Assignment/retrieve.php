<html>
<head>
	<title>Education-Courses</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
	<div class="fixed-header">
        <div class="container">
            <nav>
                <a href="index.html">Home</a>
                <a href="#">About</a>
                <a href="#">Products</a>
                <a href="#">Services</a>
                <a href="#">Contact Us</a>
            </nav>
        </div>
    </div>
    <div class="container">
    	<?php
        //$url = 'C:\xampp\htdocs\Education\courses.json'; // path to your JSON file
        $url = 'https://api.coursera.org/api/courses.v1';
        $data = file_get_contents($url); // put the contents of the file into a variable
        $characters = json_decode($data, true); // decode the JSON feed
        //$wizards = json_decode($data);
        
     ?>
        <a href="savedBooks.php"><button>Show Saved Data</button></a>
        <table border="1">
            <tbody>
                <tr>
                    <th>CourseType</th>
                    <th>ID</th>
                    <th>Name</th>
                    <th></th>
                </tr>
                <?php
                foreach ($characters['elements'] as $character) {
                    echo '<tr>';
                    echo '<td>' . $character['courseType']. '</td>';
                    echo '<td>' . $character['id'] . '</td>';
                    echo '<td>' . $character['name'] . '</td>';
                    echo '<td><a href="insert.php?type=' . $character['courseType'] .'&id=' . $character['id'] .'&name=' . $character['name'] .'"><button>Save</button></a></td>';
                    echo '</tr>';
                }
            ?>
            </tbody>
        </table>
    </div>    
    <div class="fixed-footer">
        <div class="container">Copyright &copy; 2018 Your Company</div>        
    </div>
</body>
</html>