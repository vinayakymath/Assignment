<html>
<head>
	<title>Education-Courses</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
	<div class="fixed-header">
        <div class="container">
            <nav>
                <a href="index.html">Home</a>
                <a href="#">About</a>
                <a href="#">Products</a>
                <a href="#">Services</a>
                <a href="#">Contact Us</a>
            </nav>
        </div>
    </div>
    <div class="container">
        <?php 
            include("config.php");
            $query1 = "SELECT * FROM courses";
            $result = mysqli_query($db,$query1);
        ?>
        <table border='2' cellpadding="10" cellspacing="5" bgcolor="">
            <tr>
                <th>SI.No</th>
                <th>CourseType</th>
                <th>Id</th>
                <th>Name</th>
          </tr>
<?php
while($row1=mysqli_fetch_array($result))
{
    $sino=$row1['sino'];
    $type=$row1['courseType'];
    $id=$row1['id'];
    $name=$row1['name'];
    ?>
              <tr>
                <td><?php echo $sino; ?></td>
                <td><?php echo $type; ?></td>
                <td><?php echo $id; ?></td>
                <td><?php echo $name; ?></td>
              </tr>
                
<?php }?>
            </table>


    </div>    
    <div class="fixed-footer">
        <div class="container">Copyright &copy; 2018 Your Company</div>        
    </div>
</body>
</html>