<?php 
    include("config.php");
	if(!($db))
	{
		die("Can't connect to mysql.");    
	}else{
	$courseType=$_GET['type'];
	$id=$_GET['id'];
	$name=$_GET['name'];
	$sql="INSERT INTO courses(sino,courseType,id ,name ) 
	VALUES('','$courseType','$id','$name')";
	mysqli_query($db,$sql);
	if(! $sql )
	{
	  die('Could not enter data: ' . mysqli_error());
	}
	$message = 'Data Entered successfully';
	//header('Location:registration.html');
	header('Location: retrieve.php');
	}
	mysqli_close($db)
 ?>

